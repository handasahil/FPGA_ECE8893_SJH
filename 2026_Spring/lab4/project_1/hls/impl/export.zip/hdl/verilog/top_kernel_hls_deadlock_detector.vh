
    wire dl_reset;
    wire dl_clock;
    assign dl_reset = ap_rst_n;
    assign dl_clock = ap_clk;
    wire [1:0] proc_0_data_FIFO_blk;
    wire [1:0] proc_0_data_PIPO_blk;
    wire [1:0] proc_0_start_FIFO_blk;
    wire [1:0] proc_0_TLF_FIFO_blk;
    wire [1:0] proc_0_input_sync_blk;
    wire [1:0] proc_0_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_0;
    reg [1:0] proc_dep_vld_vec_0_reg;
    wire [1:0] in_chan_dep_vld_vec_0;
    wire [9:0] in_chan_dep_data_vec_0;
    wire [1:0] token_in_vec_0;
    wire [1:0] out_chan_dep_vld_vec_0;
    wire [4:0] out_chan_dep_data_0;
    wire [1:0] token_out_vec_0;
    wire dl_detect_out_0;
    wire dep_chan_vld_1_0;
    wire [4:0] dep_chan_data_1_0;
    wire token_1_0;
    wire dep_chan_vld_4_0;
    wire [4:0] dep_chan_data_4_0;
    wire token_4_0;
    wire [1:0] proc_1_data_FIFO_blk;
    wire [1:0] proc_1_data_PIPO_blk;
    wire [1:0] proc_1_start_FIFO_blk;
    wire [1:0] proc_1_TLF_FIFO_blk;
    wire [1:0] proc_1_input_sync_blk;
    wire [1:0] proc_1_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_1;
    reg [1:0] proc_dep_vld_vec_1_reg;
    wire [1:0] in_chan_dep_vld_vec_1;
    wire [9:0] in_chan_dep_data_vec_1;
    wire [1:0] token_in_vec_1;
    wire [1:0] out_chan_dep_vld_vec_1;
    wire [4:0] out_chan_dep_data_1;
    wire [1:0] token_out_vec_1;
    wire dl_detect_out_1;
    wire dep_chan_vld_0_1;
    wire [4:0] dep_chan_data_0_1;
    wire token_0_1;
    wire dep_chan_vld_2_1;
    wire [4:0] dep_chan_data_2_1;
    wire token_2_1;
    wire [1:0] proc_2_data_FIFO_blk;
    wire [1:0] proc_2_data_PIPO_blk;
    wire [1:0] proc_2_start_FIFO_blk;
    wire [1:0] proc_2_TLF_FIFO_blk;
    wire [1:0] proc_2_input_sync_blk;
    wire [1:0] proc_2_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_2;
    reg [1:0] proc_dep_vld_vec_2_reg;
    wire [1:0] in_chan_dep_vld_vec_2;
    wire [9:0] in_chan_dep_data_vec_2;
    wire [1:0] token_in_vec_2;
    wire [1:0] out_chan_dep_vld_vec_2;
    wire [4:0] out_chan_dep_data_2;
    wire [1:0] token_out_vec_2;
    wire dl_detect_out_2;
    wire dep_chan_vld_1_2;
    wire [4:0] dep_chan_data_1_2;
    wire token_1_2;
    wire dep_chan_vld_3_2;
    wire [4:0] dep_chan_data_3_2;
    wire token_3_2;
    wire [1:0] proc_3_data_FIFO_blk;
    wire [1:0] proc_3_data_PIPO_blk;
    wire [1:0] proc_3_start_FIFO_blk;
    wire [1:0] proc_3_TLF_FIFO_blk;
    wire [1:0] proc_3_input_sync_blk;
    wire [1:0] proc_3_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_3;
    reg [1:0] proc_dep_vld_vec_3_reg;
    wire [1:0] in_chan_dep_vld_vec_3;
    wire [9:0] in_chan_dep_data_vec_3;
    wire [1:0] token_in_vec_3;
    wire [1:0] out_chan_dep_vld_vec_3;
    wire [4:0] out_chan_dep_data_3;
    wire [1:0] token_out_vec_3;
    wire dl_detect_out_3;
    wire dep_chan_vld_2_3;
    wire [4:0] dep_chan_data_2_3;
    wire token_2_3;
    wire dep_chan_vld_4_3;
    wire [4:0] dep_chan_data_4_3;
    wire token_4_3;
    wire [1:0] proc_4_data_FIFO_blk;
    wire [1:0] proc_4_data_PIPO_blk;
    wire [1:0] proc_4_start_FIFO_blk;
    wire [1:0] proc_4_TLF_FIFO_blk;
    wire [1:0] proc_4_input_sync_blk;
    wire [1:0] proc_4_output_sync_blk;
    wire [1:0] proc_dep_vld_vec_4;
    reg [1:0] proc_dep_vld_vec_4_reg;
    wire [1:0] in_chan_dep_vld_vec_4;
    wire [9:0] in_chan_dep_data_vec_4;
    wire [1:0] token_in_vec_4;
    wire [1:0] out_chan_dep_vld_vec_4;
    wire [4:0] out_chan_dep_data_4;
    wire [1:0] token_out_vec_4;
    wire dl_detect_out_4;
    wire dep_chan_vld_0_4;
    wire [4:0] dep_chan_data_0_4;
    wire token_0_4;
    wire dep_chan_vld_3_4;
    wire [4:0] dep_chan_data_3_4;
    wire token_3_4;
    wire [4:0] dl_in_vec;
    wire dl_detect_out;
    wire token_clear;
    reg [4:0] origin;

    reg ap_done_reg_0;// for module k1_vertex_transform_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_0 <= 'b0;
        end
        else begin
            ap_done_reg_0 <= k1_vertex_transform_U0.ap_done & ~k1_vertex_transform_U0.ap_continue;
        end
    end

    reg ap_done_reg_1;// for module k2_perspective_divide_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_1 <= 'b0;
        end
        else begin
            ap_done_reg_1 <= k2_perspective_divide_U0.ap_done & ~k2_perspective_divide_U0.ap_continue;
        end
    end

    reg ap_done_reg_2;// for module Block_entry_screen_tris_v0_x_rd_proc_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_2 <= 'b0;
        end
        else begin
            ap_done_reg_2 <= Block_entry_screen_tris_v0_x_rd_proc_U0.ap_done & ~Block_entry_screen_tris_v0_x_rd_proc_U0.ap_continue;
        end
    end

    reg ap_done_reg_3;// for module k5_deferred_lighting_U0
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            ap_done_reg_3 <= 'b0;
        end
        else begin
            ap_done_reg_3 <= k5_deferred_lighting_U0.ap_done & ~k5_deferred_lighting_U0.ap_continue;
        end
    end

    // Process: entry_proc_U0
    top_kernel_hls_deadlock_detect_unit #(5, 0, 2, 2) top_kernel_hls_deadlock_detect_unit_0 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_0),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_0),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_0),
        .token_in_vec(token_in_vec_0),
        .dl_detect_in(dl_detect_out),
        .origin(origin[0]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_0),
        .out_chan_dep_data(out_chan_dep_data_0),
        .token_out_vec(token_out_vec_0),
        .dl_detect_out(dl_in_vec[0]));

    assign proc_0_data_FIFO_blk[0] = 1'b0 | (~entry_proc_U0.out_pixels_c_blk_n);
    assign proc_0_data_PIPO_blk[0] = 1'b0;
    assign proc_0_start_FIFO_blk[0] = 1'b0;
    assign proc_0_TLF_FIFO_blk[0] = 1'b0;
    assign proc_0_input_sync_blk[0] = 1'b0;
    assign proc_0_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_0[0] = dl_detect_out ? proc_dep_vld_vec_0_reg[0] : (proc_0_data_FIFO_blk[0] | proc_0_data_PIPO_blk[0] | proc_0_start_FIFO_blk[0] | proc_0_TLF_FIFO_blk[0] | proc_0_input_sync_blk[0] | proc_0_output_sync_blk[0]);
    assign proc_0_data_FIFO_blk[1] = 1'b0;
    assign proc_0_data_PIPO_blk[1] = 1'b0;
    assign proc_0_start_FIFO_blk[1] = 1'b0;
    assign proc_0_TLF_FIFO_blk[1] = 1'b0;
    assign proc_0_input_sync_blk[1] = 1'b0 | (ap_sync_entry_proc_U0_ap_ready & entry_proc_U0.ap_idle & ~ap_sync_k1_vertex_transform_U0_ap_ready);
    assign proc_0_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_0[1] = dl_detect_out ? proc_dep_vld_vec_0_reg[1] : (proc_0_data_FIFO_blk[1] | proc_0_data_PIPO_blk[1] | proc_0_start_FIFO_blk[1] | proc_0_TLF_FIFO_blk[1] | proc_0_input_sync_blk[1] | proc_0_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_0_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_0_reg <= proc_dep_vld_vec_0;
        end
    end
    assign in_chan_dep_vld_vec_0[0] = dep_chan_vld_1_0;
    assign in_chan_dep_data_vec_0[4 : 0] = dep_chan_data_1_0;
    assign token_in_vec_0[0] = token_1_0;
    assign in_chan_dep_vld_vec_0[1] = dep_chan_vld_4_0;
    assign in_chan_dep_data_vec_0[9 : 5] = dep_chan_data_4_0;
    assign token_in_vec_0[1] = token_4_0;
    assign dep_chan_vld_0_4 = out_chan_dep_vld_vec_0[0];
    assign dep_chan_data_0_4 = out_chan_dep_data_0;
    assign token_0_4 = token_out_vec_0[0];
    assign dep_chan_vld_0_1 = out_chan_dep_vld_vec_0[1];
    assign dep_chan_data_0_1 = out_chan_dep_data_0;
    assign token_0_1 = token_out_vec_0[1];

    // Process: k1_vertex_transform_U0
    top_kernel_hls_deadlock_detect_unit #(5, 1, 2, 2) top_kernel_hls_deadlock_detect_unit_1 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_1),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_1),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_1),
        .token_in_vec(token_in_vec_1),
        .dl_detect_in(dl_detect_out),
        .origin(origin[1]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_1),
        .out_chan_dep_data(out_chan_dep_data_1),
        .token_out_vec(token_out_vec_1),
        .dl_detect_out(dl_in_vec[1]));

    assign proc_1_data_FIFO_blk[0] = 1'b0;
    assign proc_1_data_PIPO_blk[0] = 1'b0 | (~clip_tris_is_active_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_is_active_U.t_read) | (~clip_tris_n0_x_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_n0_x_U.t_read) | (~clip_tris_n0_y_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_n0_y_U.t_read) | (~clip_tris_n0_z_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_n0_z_U.t_read) | (~clip_tris_n1_x_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_n1_x_U.t_read) | (~clip_tris_n1_y_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_n1_y_U.t_read) | (~clip_tris_n1_z_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_n1_z_U.t_read) | (~clip_tris_n2_x_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_n2_x_U.t_read) | (~clip_tris_n2_y_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_n2_y_U.t_read) | (~clip_tris_n2_z_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_n2_z_U.t_read) | (~clip_tris_v0_w_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_v0_w_U.t_read) | (~clip_tris_v0_x_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_v0_x_U.t_read) | (~clip_tris_v0_y_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_v0_y_U.t_read) | (~clip_tris_v0_z_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_v0_z_U.t_read) | (~clip_tris_v1_w_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_v1_w_U.t_read) | (~clip_tris_v1_x_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_v1_x_U.t_read) | (~clip_tris_v1_y_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_v1_y_U.t_read) | (~clip_tris_v1_z_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_v1_z_U.t_read) | (~clip_tris_v2_w_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_v2_w_U.t_read) | (~clip_tris_v2_x_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_v2_x_U.t_read) | (~clip_tris_v2_y_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_v2_y_U.t_read) | (~clip_tris_v2_z_U.i_full_n & k1_vertex_transform_U0.ap_done & ap_done_reg_0 & ~clip_tris_v2_z_U.t_read);
    assign proc_1_start_FIFO_blk[0] = 1'b0;
    assign proc_1_TLF_FIFO_blk[0] = 1'b0;
    assign proc_1_input_sync_blk[0] = 1'b0;
    assign proc_1_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_1[0] = dl_detect_out ? proc_dep_vld_vec_1_reg[0] : (proc_1_data_FIFO_blk[0] | proc_1_data_PIPO_blk[0] | proc_1_start_FIFO_blk[0] | proc_1_TLF_FIFO_blk[0] | proc_1_input_sync_blk[0] | proc_1_output_sync_blk[0]);
    assign proc_1_data_FIFO_blk[1] = 1'b0;
    assign proc_1_data_PIPO_blk[1] = 1'b0;
    assign proc_1_start_FIFO_blk[1] = 1'b0;
    assign proc_1_TLF_FIFO_blk[1] = 1'b0;
    assign proc_1_input_sync_blk[1] = 1'b0 | (ap_sync_k1_vertex_transform_U0_ap_ready & k1_vertex_transform_U0.ap_idle & ~ap_sync_entry_proc_U0_ap_ready);
    assign proc_1_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_1[1] = dl_detect_out ? proc_dep_vld_vec_1_reg[1] : (proc_1_data_FIFO_blk[1] | proc_1_data_PIPO_blk[1] | proc_1_start_FIFO_blk[1] | proc_1_TLF_FIFO_blk[1] | proc_1_input_sync_blk[1] | proc_1_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_1_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_1_reg <= proc_dep_vld_vec_1;
        end
    end
    assign in_chan_dep_vld_vec_1[0] = dep_chan_vld_0_1;
    assign in_chan_dep_data_vec_1[4 : 0] = dep_chan_data_0_1;
    assign token_in_vec_1[0] = token_0_1;
    assign in_chan_dep_vld_vec_1[1] = dep_chan_vld_2_1;
    assign in_chan_dep_data_vec_1[9 : 5] = dep_chan_data_2_1;
    assign token_in_vec_1[1] = token_2_1;
    assign dep_chan_vld_1_2 = out_chan_dep_vld_vec_1[0];
    assign dep_chan_data_1_2 = out_chan_dep_data_1;
    assign token_1_2 = token_out_vec_1[0];
    assign dep_chan_vld_1_0 = out_chan_dep_vld_vec_1[1];
    assign dep_chan_data_1_0 = out_chan_dep_data_1;
    assign token_1_0 = token_out_vec_1[1];

    // Process: k2_perspective_divide_U0
    top_kernel_hls_deadlock_detect_unit #(5, 2, 2, 2) top_kernel_hls_deadlock_detect_unit_2 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_2),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_2),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_2),
        .token_in_vec(token_in_vec_2),
        .dl_detect_in(dl_detect_out),
        .origin(origin[2]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_2),
        .out_chan_dep_data(out_chan_dep_data_2),
        .token_out_vec(token_out_vec_2),
        .dl_detect_out(dl_in_vec[2]));

    assign proc_2_data_FIFO_blk[0] = 1'b0;
    assign proc_2_data_PIPO_blk[0] = 1'b0 | (~clip_tris_v0_x_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_v0_x_U.i_write) | (~clip_tris_v0_y_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_v0_y_U.i_write) | (~clip_tris_v0_z_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_v0_z_U.i_write) | (~clip_tris_v0_w_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_v0_w_U.i_write) | (~clip_tris_v1_x_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_v1_x_U.i_write) | (~clip_tris_v1_y_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_v1_y_U.i_write) | (~clip_tris_v1_z_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_v1_z_U.i_write) | (~clip_tris_v1_w_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_v1_w_U.i_write) | (~clip_tris_v2_x_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_v2_x_U.i_write) | (~clip_tris_v2_y_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_v2_y_U.i_write) | (~clip_tris_v2_z_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_v2_z_U.i_write) | (~clip_tris_v2_w_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_v2_w_U.i_write) | (~clip_tris_n0_x_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_n0_x_U.i_write) | (~clip_tris_n0_y_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_n0_y_U.i_write) | (~clip_tris_n0_z_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_n0_z_U.i_write) | (~clip_tris_n1_x_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_n1_x_U.i_write) | (~clip_tris_n1_y_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_n1_y_U.i_write) | (~clip_tris_n1_z_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_n1_z_U.i_write) | (~clip_tris_n2_x_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_n2_x_U.i_write) | (~clip_tris_n2_y_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_n2_y_U.i_write) | (~clip_tris_n2_z_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_n2_z_U.i_write) | (~clip_tris_is_active_U.t_empty_n & k2_perspective_divide_U0.ap_idle & ~clip_tris_is_active_U.i_write);
    assign proc_2_start_FIFO_blk[0] = 1'b0;
    assign proc_2_TLF_FIFO_blk[0] = 1'b0;
    assign proc_2_input_sync_blk[0] = 1'b0;
    assign proc_2_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_2[0] = dl_detect_out ? proc_dep_vld_vec_2_reg[0] : (proc_2_data_FIFO_blk[0] | proc_2_data_PIPO_blk[0] | proc_2_start_FIFO_blk[0] | proc_2_TLF_FIFO_blk[0] | proc_2_input_sync_blk[0] | proc_2_output_sync_blk[0]);
    assign proc_2_data_FIFO_blk[1] = 1'b0;
    assign proc_2_data_PIPO_blk[1] = 1'b0 | (~screen_tris_v0_x_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_v0_x_U.t_read) | (~screen_tris_v0_y_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_v0_y_U.t_read) | (~screen_tris_v0_z_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_v0_z_U.t_read) | (~screen_tris_v1_x_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_v1_x_U.t_read) | (~screen_tris_v1_y_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_v1_y_U.t_read) | (~screen_tris_v1_z_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_v1_z_U.t_read) | (~screen_tris_v2_x_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_v2_x_U.t_read) | (~screen_tris_v2_y_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_v2_y_U.t_read) | (~screen_tris_v2_z_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_v2_z_U.t_read) | (~screen_tris_n0_x_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_n0_x_U.t_read) | (~screen_tris_n0_y_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_n0_y_U.t_read) | (~screen_tris_n0_z_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_n0_z_U.t_read) | (~screen_tris_n1_x_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_n1_x_U.t_read) | (~screen_tris_n1_y_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_n1_y_U.t_read) | (~screen_tris_n1_z_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_n1_z_U.t_read) | (~screen_tris_n2_x_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_n2_x_U.t_read) | (~screen_tris_n2_y_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_n2_y_U.t_read) | (~screen_tris_n2_z_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_n2_z_U.t_read) | (~screen_tris_is_active_U.i_full_n & k2_perspective_divide_U0.ap_done & ap_done_reg_1 & ~screen_tris_is_active_U.t_read);
    assign proc_2_start_FIFO_blk[1] = 1'b0;
    assign proc_2_TLF_FIFO_blk[1] = 1'b0;
    assign proc_2_input_sync_blk[1] = 1'b0;
    assign proc_2_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_2[1] = dl_detect_out ? proc_dep_vld_vec_2_reg[1] : (proc_2_data_FIFO_blk[1] | proc_2_data_PIPO_blk[1] | proc_2_start_FIFO_blk[1] | proc_2_TLF_FIFO_blk[1] | proc_2_input_sync_blk[1] | proc_2_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_2_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_2_reg <= proc_dep_vld_vec_2;
        end
    end
    assign in_chan_dep_vld_vec_2[0] = dep_chan_vld_1_2;
    assign in_chan_dep_data_vec_2[4 : 0] = dep_chan_data_1_2;
    assign token_in_vec_2[0] = token_1_2;
    assign in_chan_dep_vld_vec_2[1] = dep_chan_vld_3_2;
    assign in_chan_dep_data_vec_2[9 : 5] = dep_chan_data_3_2;
    assign token_in_vec_2[1] = token_3_2;
    assign dep_chan_vld_2_1 = out_chan_dep_vld_vec_2[0];
    assign dep_chan_data_2_1 = out_chan_dep_data_2;
    assign token_2_1 = token_out_vec_2[0];
    assign dep_chan_vld_2_3 = out_chan_dep_vld_vec_2[1];
    assign dep_chan_data_2_3 = out_chan_dep_data_2;
    assign token_2_3 = token_out_vec_2[1];

    // Process: Block_entry_screen_tris_v0_x_rd_proc_U0
    top_kernel_hls_deadlock_detect_unit #(5, 3, 2, 2) top_kernel_hls_deadlock_detect_unit_3 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_3),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_3),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_3),
        .token_in_vec(token_in_vec_3),
        .dl_detect_in(dl_detect_out),
        .origin(origin[3]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_3),
        .out_chan_dep_data(out_chan_dep_data_3),
        .token_out_vec(token_out_vec_3),
        .dl_detect_out(dl_in_vec[3]));

    assign proc_3_data_FIFO_blk[0] = 1'b0;
    assign proc_3_data_PIPO_blk[0] = 1'b0 | (~depth_buffer_U.i_full_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_done & ap_done_reg_2 & ~depth_buffer_U.t_read) | (~normal_buffer_x_U.i_full_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_done & ap_done_reg_2 & ~normal_buffer_x_U.t_read) | (~normal_buffer_y_U.i_full_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_done & ap_done_reg_2 & ~normal_buffer_y_U.t_read) | (~normal_buffer_z_U.i_full_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_done & ap_done_reg_2 & ~normal_buffer_z_U.t_read);
    assign proc_3_start_FIFO_blk[0] = 1'b0;
    assign proc_3_TLF_FIFO_blk[0] = 1'b0;
    assign proc_3_input_sync_blk[0] = 1'b0;
    assign proc_3_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_3[0] = dl_detect_out ? proc_dep_vld_vec_3_reg[0] : (proc_3_data_FIFO_blk[0] | proc_3_data_PIPO_blk[0] | proc_3_start_FIFO_blk[0] | proc_3_TLF_FIFO_blk[0] | proc_3_input_sync_blk[0] | proc_3_output_sync_blk[0]);
    assign proc_3_data_FIFO_blk[1] = 1'b0;
    assign proc_3_data_PIPO_blk[1] = 1'b0 | (~screen_tris_is_active_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_is_active_U.i_write) | (~screen_tris_n0_x_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_n0_x_U.i_write) | (~screen_tris_n0_y_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_n0_y_U.i_write) | (~screen_tris_n0_z_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_n0_z_U.i_write) | (~screen_tris_n1_x_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_n1_x_U.i_write) | (~screen_tris_n1_y_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_n1_y_U.i_write) | (~screen_tris_n1_z_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_n1_z_U.i_write) | (~screen_tris_n2_x_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_n2_x_U.i_write) | (~screen_tris_n2_y_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_n2_y_U.i_write) | (~screen_tris_n2_z_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_n2_z_U.i_write) | (~screen_tris_v0_x_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_v0_x_U.i_write) | (~screen_tris_v0_y_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_v0_y_U.i_write) | (~screen_tris_v0_z_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_v0_z_U.i_write) | (~screen_tris_v1_x_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_v1_x_U.i_write) | (~screen_tris_v1_y_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_v1_y_U.i_write) | (~screen_tris_v1_z_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_v1_z_U.i_write) | (~screen_tris_v2_x_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_v2_x_U.i_write) | (~screen_tris_v2_y_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_v2_y_U.i_write) | (~screen_tris_v2_z_U.t_empty_n & Block_entry_screen_tris_v0_x_rd_proc_U0.ap_idle & ~screen_tris_v2_z_U.i_write);
    assign proc_3_start_FIFO_blk[1] = 1'b0;
    assign proc_3_TLF_FIFO_blk[1] = 1'b0;
    assign proc_3_input_sync_blk[1] = 1'b0;
    assign proc_3_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_3[1] = dl_detect_out ? proc_dep_vld_vec_3_reg[1] : (proc_3_data_FIFO_blk[1] | proc_3_data_PIPO_blk[1] | proc_3_start_FIFO_blk[1] | proc_3_TLF_FIFO_blk[1] | proc_3_input_sync_blk[1] | proc_3_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_3_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_3_reg <= proc_dep_vld_vec_3;
        end
    end
    assign in_chan_dep_vld_vec_3[0] = dep_chan_vld_2_3;
    assign in_chan_dep_data_vec_3[4 : 0] = dep_chan_data_2_3;
    assign token_in_vec_3[0] = token_2_3;
    assign in_chan_dep_vld_vec_3[1] = dep_chan_vld_4_3;
    assign in_chan_dep_data_vec_3[9 : 5] = dep_chan_data_4_3;
    assign token_in_vec_3[1] = token_4_3;
    assign dep_chan_vld_3_4 = out_chan_dep_vld_vec_3[0];
    assign dep_chan_data_3_4 = out_chan_dep_data_3;
    assign token_3_4 = token_out_vec_3[0];
    assign dep_chan_vld_3_2 = out_chan_dep_vld_vec_3[1];
    assign dep_chan_data_3_2 = out_chan_dep_data_3;
    assign token_3_2 = token_out_vec_3[1];

    // Process: k5_deferred_lighting_U0
    top_kernel_hls_deadlock_detect_unit #(5, 4, 2, 2) top_kernel_hls_deadlock_detect_unit_4 (
        .reset(dl_reset),
        .clock(dl_clock),
        .proc_dep_vld_vec(proc_dep_vld_vec_4),
        .in_chan_dep_vld_vec(in_chan_dep_vld_vec_4),
        .in_chan_dep_data_vec(in_chan_dep_data_vec_4),
        .token_in_vec(token_in_vec_4),
        .dl_detect_in(dl_detect_out),
        .origin(origin[4]),
        .token_clear(token_clear),
        .out_chan_dep_vld_vec(out_chan_dep_vld_vec_4),
        .out_chan_dep_data(out_chan_dep_data_4),
        .token_out_vec(token_out_vec_4),
        .dl_detect_out(dl_in_vec[4]));

    assign proc_4_data_FIFO_blk[0] = 1'b0 | (~k5_deferred_lighting_U0.framebuffer_blk_n);
    assign proc_4_data_PIPO_blk[0] = 1'b0;
    assign proc_4_start_FIFO_blk[0] = 1'b0;
    assign proc_4_TLF_FIFO_blk[0] = 1'b0;
    assign proc_4_input_sync_blk[0] = 1'b0;
    assign proc_4_output_sync_blk[0] = 1'b0;
    assign proc_dep_vld_vec_4[0] = dl_detect_out ? proc_dep_vld_vec_4_reg[0] : (proc_4_data_FIFO_blk[0] | proc_4_data_PIPO_blk[0] | proc_4_start_FIFO_blk[0] | proc_4_TLF_FIFO_blk[0] | proc_4_input_sync_blk[0] | proc_4_output_sync_blk[0]);
    assign proc_4_data_FIFO_blk[1] = 1'b0;
    assign proc_4_data_PIPO_blk[1] = 1'b0 | (~depth_buffer_U.t_empty_n & k5_deferred_lighting_U0.ap_idle & ~depth_buffer_U.i_write) | (~normal_buffer_x_U.t_empty_n & k5_deferred_lighting_U0.ap_idle & ~normal_buffer_x_U.i_write) | (~normal_buffer_y_U.t_empty_n & k5_deferred_lighting_U0.ap_idle & ~normal_buffer_y_U.i_write) | (~normal_buffer_z_U.t_empty_n & k5_deferred_lighting_U0.ap_idle & ~normal_buffer_z_U.i_write);
    assign proc_4_start_FIFO_blk[1] = 1'b0;
    assign proc_4_TLF_FIFO_blk[1] = 1'b0;
    assign proc_4_input_sync_blk[1] = 1'b0;
    assign proc_4_output_sync_blk[1] = 1'b0;
    assign proc_dep_vld_vec_4[1] = dl_detect_out ? proc_dep_vld_vec_4_reg[1] : (proc_4_data_FIFO_blk[1] | proc_4_data_PIPO_blk[1] | proc_4_start_FIFO_blk[1] | proc_4_TLF_FIFO_blk[1] | proc_4_input_sync_blk[1] | proc_4_output_sync_blk[1]);
    always @ (negedge dl_reset or posedge dl_clock) begin
        if (~dl_reset) begin
            proc_dep_vld_vec_4_reg <= 'b0;
        end
        else begin
            proc_dep_vld_vec_4_reg <= proc_dep_vld_vec_4;
        end
    end
    assign in_chan_dep_vld_vec_4[0] = dep_chan_vld_0_4;
    assign in_chan_dep_data_vec_4[4 : 0] = dep_chan_data_0_4;
    assign token_in_vec_4[0] = token_0_4;
    assign in_chan_dep_vld_vec_4[1] = dep_chan_vld_3_4;
    assign in_chan_dep_data_vec_4[9 : 5] = dep_chan_data_3_4;
    assign token_in_vec_4[1] = token_3_4;
    assign dep_chan_vld_4_0 = out_chan_dep_vld_vec_4[0];
    assign dep_chan_data_4_0 = out_chan_dep_data_4;
    assign token_4_0 = token_out_vec_4[0];
    assign dep_chan_vld_4_3 = out_chan_dep_vld_vec_4[1];
    assign dep_chan_data_4_3 = out_chan_dep_data_4;
    assign token_4_3 = token_out_vec_4[1];


`include "top_kernel_hls_deadlock_report_unit.vh"
